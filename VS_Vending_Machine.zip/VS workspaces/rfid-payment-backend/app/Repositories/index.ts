import RfidRepo from './RfidRepo'

export { RfidRepo }
