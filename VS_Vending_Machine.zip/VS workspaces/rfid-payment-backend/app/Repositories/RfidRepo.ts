import { Rfid } from 'App/Models'

export default class RfidRepo {
  public static async register(payload: object) {
    const data = await Rfid.create({ ...payload, balance: 0 , status : 'active'})
    return { message: 'Registered Successfully !', data }
  }

  public static async signIn(userName: string, pin: number) {
    const data = await Rfid.findByOrFail('userName', userName)
    if (data.pin === pin) return { success: true, message: 'Logged In Successfully', data }
    else return { success: false, message: 'Incorrect Pin' }
  }

  public static async topUp(userName: string, amount: number) {
    const data = await Rfid.findByOrFail('user_name', userName)
    data.balance = data.balance + amount
    data.save()
    return { message: `${amount} Recharged Successfully `, data }
  }

  public static async block(userName: string, pin: number) {
    const data = await Rfid.findByOrFail('user_name', userName)
    if (data.pin === pin){
    data.status === 'active' ? data.status = 'blocked' : data.status = 'active'
    data.save()
    return data.status === 'blocked' ? { message: `Card Blocked`, data } : { message : 'Card is Active' , data }
  }

    else
      return {message: `Invalid PIN `, data }

    
  }
}
