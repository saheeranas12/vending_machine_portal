import { schema, CustomMessages, rules } from '@ioc:Adonis/Core/Validator'
import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'

export default class RfidValidator {
  constructor(protected ctx: HttpContextContract) {}

  public get data() {
    const pin = this.ctx.request.input('pin')
    return {
      ...this.ctx.request.all(),
      pin:
      pin && Number.isInteger(Number(pin)) ? Number(pin) : pin,
    }
  }

  public schema = schema.create({
    uid: schema.string([rules.unique({ table: 'rfids', column: 'uid' })]),
    userName: schema.string([
      rules.unique({ table: 'rfids', column: 'user_name' }),
      rules.maxLength(10),
    ]),
    pin: schema.number([rules.unsigned()]),
  })

  public messages: CustomMessages = {}
}
