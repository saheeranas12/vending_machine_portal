<template>
  <div class="about" style="text-align: center;">
    <br>
    <h1>Welcome {{userData.user_name}}</h1>
    <UserPage :user = "{...userData}"/>
  </div>

</template>
<script>
import UserPage from '../components/UserPage.vue';
export default {
    name: 'AboutView',
    boolean : true,
    components: {
    UserPage
  },
  data : () => ({
    userData : {}
  }),
  created(){
    this.$watch(
      () => this.$route.params,
      () => {
        this.fetchData()
      },
      { immediate: true }
    )
  },
  methods :{
    fetchData() {
      this.error = this.post = null
      this.loading = true
      const userData = this.$route.params.user
      this.userData = {...userData}
    },
  },
}
</script>
