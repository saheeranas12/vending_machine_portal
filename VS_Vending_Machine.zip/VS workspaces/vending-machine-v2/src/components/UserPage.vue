<template>
  <div class="d-flex justify-center mb-6">
      
      <v-card
elevation="2"
shaped
width="1000px"
class="ma-3 text-center"
>
<br>
<v-row>
<v-col>
  <h3>
      Your account balance : {{user.balance}}
    </h3>
    <br>
</v-col>
</v-row>
<v-row>
<v-col>
  <v-row>
      <v-col>
          <h3>
      Click here to top up 
    </h3>
    <v-text-field style="display: none;" name="userName" v-model = "userName" :value= "userNameFromDb.user_name"></v-text-field>
    <br>
    <v-text-field
    label="Enter amount"
    placeholder="Enter amount"
    type="number"
    filled 
    dense
  rounded 
  v-model = "amount"
>
      
    </v-text-field>
      </v-col>
      <v-col>
          <v-btn
    style="background-color: purple ;color: white;"
      elevation="4"
      :disabled = "userNameFromDb.status === 'blocked'"
      @click = "topUp({userName,amount})">
    Top Up 
    </v-btn>
      </v-col>
  </v-row>
  
  
</v-col>
<v-col>

  <v-row>
      <v-col>
          <h3>
      Click here to block card 
    </h3>
    <br>
    <v-text-field
    label="Enter Pin"
    placeholder="Enter Pin"
    type="number"
    filled 
    dense
  rounded 
  v-model = "pin"
></v-text-field>
      </v-col>
      <v-col>
          <v-btn
    style="background-color: purple ;color: white;"
      elevation="4"
      :disabled = "userNameFromDb.status === 'blocked'"
      @click = "blockCard({userName,pin})">
    Block Card 
    </v-btn>
      </v-col>
  </v-row>
</v-col>

</v-row>
<v-row><br>
  <v-col>
    <h4
  style="text-align: center;"
  >Account Status : 
      <span v-if = "userNameFromDb.status == 'active'" style="color: green;">{{user.status}}</span>
      <span v-if = "userNameFromDb.status == 'blocked'" style="color: red;">{{user.status}}<br>Please contact admin : +917397381007</span>
    </h4>

  </v-col>
  
</v-row>
<br>
</v-card>
  </div>




</template>
<script>
import axios from 'axios';
export default {
  name: 'UserPage',
  props : ['user'],
  data: () => ({
      userName : "",
      amount : "",
      userData : {},
      userNameFromDb : "",
      pin : ""
  }),
  created(){
    console.log(this.user);
    this.userNameFromDb = this.user
    this.userName = this.userNameFromDb.user_name
  },
  mounted : async function () {
  this.instance =  axios.create({ baseURL: "http://127.0.0.1:3333" , headers:{'Content-type' : "application/json",}})
  },
  methods : {
    async topUp({userName ,amount}){
      console.log({userName,amount});
      const data = await this.instance.post("/topUpCard",{userName,amount}).then((res)=> res.data)
      console.log(data.data);
      const user = data.data
      if(data['success']){
      this.userData=user
      this.user = this.userData
      this.userName = this.userNameFromDb.user_name
    }
    this.amount = ""
    },

    async blockCard({userName ,pin}){
      console.log({userName,pin});
      const data = await this.instance.post("/cardBlock",{userName,pin}).then((res)=> res.data)
      console.log(data.data);
      const user = data.data
      if(data['success']){
      this.userData=user
      this.user = this.userData
      this.userName = this.userNameFromDb.user_name
    }
    this.pin = ""
    }

  }
}


  
</script>