<template>
    <v-container>
    <h1 style="text-align: center;">
  SRM Automats Payment Portal
</h1>
<v-row style="margin-top: 100px;">
  <v-col>
    <v-container class="d-flex flex-row mb-6" >
    <v-card
    elevation="2"
  shaped
  width="1200px">
  <br>
      <h2 style="text-align: center;">
        About The Project
      </h2>
      <br>
      <h3 style="margin-left:30px;margin-right:30px">
        The main objective of our project is to construct an automatic vending machine, which can be installed in schools, colleges, hospitals, and other public places to dispense food, pens, pencils, and sanitary napkins as per need of the society.
        In this technology we have planned other cashless RFID payment. It’s a very easy and convenient method of purchasing than the conventional way of going to a store.
      </h3>
      <br>
    </v-card>
  </v-container>
  </v-col>
  <v-col>
    <v-container class="d-flex flex-row-reverse" >
      <SignIn v-if="boolean"></SignIn>
      <SignUp v-else></SignUp>
</v-container>
  <v-col>
    <v-row  class="d-flex justify-end">
      <h3
      v-if="boolean">
        Register New Card &nbsp; | &nbsp;
      </h3>
      <h3
      v-else>
        Already Have An Account &nbsp; | &nbsp;
      </h3>
      <v-btn
      style="background-color: white ; color: purple;"
        elevation="4"
        v-if="boolean"
        @click = "boolean = !boolean"
      >
      Sign up 
      </v-btn>
      <v-btn
        color="white"
        elevation="4"
        @click = "boolean = !boolean"
        style="background-color: white ; color: purple;"
        v-else
      >
      Sign In
      </v-btn>
    </v-row>

  </v-col>


  </v-col>
  
</v-row>
  
 
  </v-container>
</template>

<script>
import SignIn from './SignIn.vue';
import SignUp from './SignUp.vue'
  export default {
    name: 'HelloWorld',
    boolean : true,
    components: {
    SignIn,
    SignUp
  },

    data: () => ({
      boolean : true,
      ecosystem: [
        {
          text: 'vuetify-loader',
          href: 'https://github.com/vuetifyjs/vuetify-loader',
        },
        {
          text: 'github',
          href: 'https://github.com/vuetifyjs/vuetify',
        },
        {
          text: 'awesome-vuetify',
          href: 'https://github.com/vuetifyjs/awesome-vuetify',
        },
      ],
      importantLinks: [
        {
          text: 'Documentation',
          href: 'https://vuetifyjs.com',
        },
        {
          text: 'Chat',
          href: 'https://community.vuetifyjs.com',
        },
        {
          text: 'Made with Vuetify',
          href: 'https://madewithvuejs.com/vuetify',
        },
        {
          text: 'Twitter',
          href: 'https://twitter.com/vuetifyjs',
        },
        {
          text: 'Articles',
          href: 'https://medium.com/vuetify',
        },
      ],
      whatsNext: [
        {
          text: 'Explore components',
          href: 'https://vuetifyjs.com/components/api-explorer',
        },
        {
          text: 'Select a layout',
          href: 'https://vuetifyjs.com/getting-started/pre-made-layouts',
        },
        {
          text: 'Frequently Asked Questions',
          href: 'https://vuetifyjs.com/getting-started/frequently-asked-questions',
        },
      ],
    }),
  }
</script>
