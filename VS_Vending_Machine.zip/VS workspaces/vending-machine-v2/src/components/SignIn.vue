<template>
  <v-card
  elevation="2"
  shaped
  width="450px"
>
<br>
<h2 style="text-align: center;">
  Please log in to continue...
</h2>
<br>
<v-row  class="d-flex justify-center mb-6">
  <v-col   cols="18"
            sm="10"
            md="10">
    <v-text-field
    label="Username"
    placeholder="Enter your username"
    filled
    dense
    rounded 
    v-model = "userName"
></v-text-field>

<v-text-field
    type="number"
    label="PIN"
    placeholder="Enter your PIN"
    filled
    dense
    rounded 
    v-model = "pin"
    ></v-text-field>


<div class="d-flex justify-center mb-6">

<v-btn
  color="purple"
  elevation="4"
  @click="signIn({userName,pin})"
>
Sign In
</v-btn>

</div>
  </v-col>
</v-row>

   


</v-card>
</template>
<script>
import axios from 'axios'
export default {
    name: 'SignIn',

    data: () => ({
        userName : "",
        pin : "",

    }),
    mounted : async function () {
    this.instance =  axios.create({ baseURL: "http://127.0.0.1:3333" , headers:{'Content-type' : "application/json",}})
    },
    methods:{
      async signIn({userName,pin}){
        const data = await this.instance.post("/signIn",{userName,pin}).then((res)=> res.data)
        console.log(data.data);
        const user = data.data
        if(data['success'])
            this.$router.push({ name: 'about', params : {user : user}, path :  '/about' });
      }
    }
}
</script>