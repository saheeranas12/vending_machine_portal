<template>
  <v-app>
    <v-app-bar
      app
      color="blue"
      dark
    >
    <h3>
      SRM Automats
    </h3>
      <v-spacer></v-spacer>
    </v-app-bar>
    
    <v-main>
      <router-view/>
    </v-main>
  </v-app>
</template>

<script>

export default {
  name: 'App',

  data: () => ({
    //
  }),
};
</script>
